import { createRouter, createWebHistory } from 'vue-router'
import Login from '@/views/Login/index.vue'
import Introduction from '@/views/Introduction/index.vue'
import ScholarView from '../views/scholar/scholarPortal.vue'
import PersonalScholarView from '../views/scholar/personalScholar/personalPortal.vue'
import AcademicView from '../views/academic/index.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  // path和component对应关系的位置
  routes: [
    {
      path: '/',
      name: 'introduction',
    },
    {
      path: '/intro',
      name: 'intro',
      component: Introduction
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/scholar',
      name: 'scholar',
      component: ScholarView
    },
    {
      path: '/personalScholar',
      name: 'personalScholar',
      component: PersonalScholarView
    },
    {
      path: '/academic',
      name: 'academic',
      component: AcademicView
    }
  ]
})

export default router