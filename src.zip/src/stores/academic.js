import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useAcademicStore = defineStore('academic', () => {
    const essayInfo = {
        id:1,
        title:'NLP (natural language processing) for NLP (naturallanguage programming)',
        year:2023,
        n_citation:10,
        url:'xx',
        doi:'10.1007/11671299 34',
        abstract:'Natural Language Processing holds great promise for making computer interfaces that are easier to use for people, sincepeople will (hopefully) be able to talk to the computer in their owm language, rather than learn a specialized language otcomputer commands For proeramming. however. thenecessity of a formal proerammine laneuaee for communicating witha computer has always been taken for granted. We would',
        keywords:['xdxxxx','sssddsds'],
        authors:[
            {
                name:'Rada Mihalcea'
            },
            {
                name:'Rada Mihalcea'
            },
            {
                name:'Rada Mihalcea'
            },
        ],
        institution:'CICLing',
    }

    return{
        essayInfo,
    }
}, {
    persist: true,
  })